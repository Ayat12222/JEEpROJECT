package ma.formations.jpa.presentation.controller;

public class DeletearticleServlet {
}
