package ma.formations.jpa.presentation.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import ma.formations.jpa.service.IService;
import ma.formations.jpa.service.ServiceImpl;

@WebServlet("/Add")
public class AddarticleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private IService service = new ServiceImpl();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Redirection vers le formulaire d'ajout d'article
        request.getRequestDispatcher("/view/addArticle.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Récupération des données du formulaire
        String description = request.getParameter("description");
        Double quantite = Double.valueOf(request.getParameter("quantite"));
        Double price = Double.valueOf(request.getParameter("price"));

        // Appel du service pour ajouter un nouvel article
        service.addArticle(description, quantite, price);

        // Redirection vers une page de confirmation ou de succès
        response.sendRedirect(request.getContextPath() + "/articles.do");
    }
}
